
export enum View {
  HOME = 'HOME',
  CHAT = 'CHAT',
  TEXT_CHAT = 'TEXT_CHAT',
  PRACTICE = 'PRACTICE',
  READING = 'READING',
  EXERCISES = 'EXERCISES',
  PROFILE = 'PROFILE'
}

export type ProficiencyLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export interface Mistake {
  id: string;
  original: string;
  correction: string;
  explanation: string;
  timestamp: number;
}

export interface Vocabulary {
  word: string;
  definition: string;
  example: string;
  timestamp: number;
}

export interface UserProfile {
  name: string;
  level: ProficiencyLevel;
  objectives: string[];
  stats: {
    totalSessions: number;
    totalMinutes: number;
    streakDays: number;
    lastActive: number;
  };
  memory: {
    recentMistakes: Mistake[];
    vocabulary: Vocabulary[];
  };
}

export interface Scenario {
  id: string;
  title: string;
  description: string;
  icon: string;
  difficulty: ProficiencyLevel;
  systemInstruction: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'error';

export interface AudioConfig {
  sampleRate: number;
  voiceName: string;
}
