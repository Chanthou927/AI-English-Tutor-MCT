# FluentFlow Architecture

## System Overview

FluentFlow is a client-side Single Page Application (SPA) built with React and TypeScript. It interacts directly with the Google Gemini API to provide real-time English tutoring.

### High-Level Data Flow

```mermaid
graph LR
    User[User] <-->|Audio/UI| Client[React Frontend]
    Client <-->|WebSockets (Live API)| GeminiLive[Gemini Live API]
    Client <-->|REST (Content API)| GeminiFlash[Gemini 2.5 Flash]
    Client <-->|Persistence| LocalStorage[Browser Storage]
```

---

## Core Workflows

### 1. Live Conversation (Audio-to-Audio)

This workflow powers the "Real Conversations" feature using the Gemini Multimodal Live API.

1.  **Input**: 
    *   The browser's `AudioContext` captures microphone input.
    *   Audio is downsampled to 16kHz and converted to raw PCM 16-bit format (`utils/audio.ts`).
    *   Data is streamed via WebSocket `session.sendRealtimeInput`.
2.  **Processing (The Agent)**:
    *   **System Instruction**: Injected at connection start. Contains the persona (e.g., "Barista"), user level, and pedagogical goals.
    *   **Model**: `gemini-2.5-flash-native-audio-preview`. It processes audio directly without intermediate text-to-speech steps (native multimodal).
3.  **Output**:
    *   The API returns chunks containing `modelTurn` (Base64 encoded PCM audio) and `outputTranscription`.
    *   Frontend queues these chunks in an audio buffer and plays them sequentially to ensure gapless playback.

### 2. Reading Practice (Multimodal Analysis)

This workflow uses the standard Generate Content API to analyze pronunciation.

1.  **Input**: User records audio while reading a generated text passage.
2.  **Payload**: The frontend creates a `multipart` request containing:
    *   **Text Part**: A prompt asking for a score and specific feedback.
    *   **Media Part**: The recorded WAV/PCM audio blob converted to Base64.
3.  **Processing**: Gemini analyzes the audio wave directly against the expected text context.
4.  **Output**: Returns structured JSON (via `responseSchema`) containing a score (1-10), feedback text, and a list of mispronounced words.

### 3. Feedback Loop (Text Analysis)

This workflow turns conversation history into long-term memory.

1.  **Trigger**: End of a text chat session.
2.  **Input**: The full chat transcript.
3.  **Agent Workflow**:
    *   Prompt: "Analyze this transcript. Extract grammatical mistakes and useful vocabulary."
    *   Config: JSON Mode enabled.
4.  **Storage**: The resulting JSON is parsed and stored in `localStorage` via the `userState` service.
5.  **Recall**: In future sessions, the `PromptsService` reads this state and injects: *"User previously struggled with [word]. Encourage practice."* into the System Instruction.

---

## Prompt Engineering Layer

The application uses a dynamic `PromptTemplates` service to construct contexts on the fly.

### Context Injection Strategy

Instead of static system instructions, we build them dynamically:

```typescript
// services/prompts.ts
const instruction = [
  BasePersona(scenario),       // "You are a Doctor..."
  UserLevel(profile.level),    // "User is Intermediate..."
  Memory(recentMistakes),      // "Correct usage of 'make' vs 'do'..."
  PedagogyRules                // "Don't interrupt too often..."
].join('\n');
```

### Structured Output (JSON Mode)

For logic-heavy tasks (Quizzes, Analysis, Scoring), we strictly enforce JSON output using `responseMimeType: 'application/json'` and `responseSchema`. This ensures the frontend can render UI components (like Multiple Choice buttons) reliably without parsing regex.

---

## Audio Pipeline Details

*   **Input (Microphone)**: `MediaStream` -> `ScriptProcessorNode` -> `Float32` to `Int16` conversion -> Gemini.
*   **Output (Speaker)**: Base64 String -> `atob` -> `Float32` conversion -> `AudioBufferSourceNode` -> Destination.
*   **VAD (Voice Activity Detection)**: Handled server-side by the Gemini Live API, which sends `interrupted: true` signals to the client to stop audio playback immediately when the user interrupts.
