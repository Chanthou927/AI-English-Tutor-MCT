import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export const config = { api: { bodyParser: { sizeLimit: '4mb' } } };

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).end();

  try {
    const { messages, systemInstruction } = req.body;

    // Construct history for chat format
    // Support both simple text messages and complex parts (for multimodal)
    const history = messages.slice(0, -1).map((m: any) => ({
      role: m.role,
      parts: m.parts || [{ text: m.text }]
    }));

    const lastMessage = messages[messages.length - 1];
    const lastMessageParts = lastMessage.parts || [{ text: lastMessage.text }];

    const chat = ai.chats.create({
      model: "gemini-2.5-flash",
      config: { systemInstruction },
      history: history
    });

    const result = await chat.sendMessage({ content: lastMessageParts });
    const text = result.text;

    res.status(200).json({ text });
  } catch (error: any) {
    console.error('API Error:', error);
    res.status(500).json({ error: error.message || 'Internal Server Error' });
  }
}