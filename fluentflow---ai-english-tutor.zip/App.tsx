
import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import LiveSession from './components/LiveSession';
import TextChat from './components/TextChat';
import PracticeMode from './components/PracticeMode';
import Profile from './components/Profile';
import ReadingPractice from './components/ReadingPractice';
import SmartExercises from './components/SmartExercises';
import ErrorBoundary from './components/ErrorBoundary';
import { I18nProvider, useTranslation } from './contexts/I18nContext';
import { analytics } from './services/analytics';
import { logger } from './services/logger';
import { View, Scenario } from './types';

// Separate component to use translation hook
const AppContent: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.HOME);
  const [activeScenario, setActiveScenario] = useState<Scenario | null>(null);
  const { t } = useTranslation();

  useEffect(() => {
    logger.init();
    analytics.init();
  }, []);

  const handleNavigate = (view: View) => {
    analytics.track('navigation', { from: currentView, to: view });
    setCurrentView(view);
    if (view !== View.CHAT) {
      setActiveScenario(null);
    }
  };

  const handleScenarioSelect = (scenario: Scenario) => {
    analytics.track('start_scenario', { scenarioId: scenario.id, title: scenario.title });
    setActiveScenario(scenario);
    setCurrentView(View.CHAT);
  };

  const renderContent = () => {
    switch (currentView) {
      case View.HOME:
        return (
          <div className="max-w-5xl mx-auto px-4 py-12 text-center">
            <h1 className="text-4xl md:text-6xl font-extrabold text-slate-900 tracking-tight mb-6">
              {t('home.title')} <span className="text-indigo-600">{t('home.subtitle')}</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10">
              {t('home.description')}
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
                <button 
                  onClick={() => handleNavigate(View.CHAT)}
                  className="px-8 py-4 bg-indigo-600 text-white rounded-xl font-bold shadow-lg hover:bg-indigo-700 transition-all transform hover:-translate-y-1"
                >
                  {t('home.ctaPrimary')}
                </button>
                <button 
                  onClick={() => handleNavigate(View.READING)}
                  className="px-8 py-4 bg-white text-indigo-600 border-2 border-indigo-100 rounded-xl font-bold hover:border-indigo-200 hover:bg-indigo-50 transition-all"
                >
                  {t('home.ctaSecondary')}
                </button>
            </div>

            <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
                <div 
                    onClick={() => handleNavigate(View.CHAT)}
                    className="p-6 bg-white rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-all cursor-pointer"
                >
                    <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center text-2xl mb-4 mx-auto" aria-hidden="true">💬</div>
                    <h3 className="text-lg font-bold text-slate-900 mb-2">Real Conversations</h3>
                    <p className="text-slate-500">Low latency voice AI that feels like talking to a real person.</p>
                </div>
                <div 
                    onClick={() => handleNavigate(View.EXERCISES)}
                    className="p-6 bg-white rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-all cursor-pointer"
                >
                    <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center text-2xl mb-4 mx-auto" aria-hidden="true">🧠</div>
                    <h3 className="text-lg font-bold text-slate-900 mb-2">Smart Exercises</h3>
                    <p className="text-slate-500">Quizzes auto-generated from your previous mistakes.</p>
                </div>
                <div 
                    onClick={() => handleNavigate(View.READING)}
                    className="p-6 bg-white rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-all cursor-pointer"
                >
                    <div className="w-12 h-12 bg-green-100 text-green-600 rounded-lg flex items-center justify-center text-2xl mb-4 mx-auto" aria-hidden="true">📖</div>
                    <h3 className="text-lg font-bold text-slate-900 mb-2">Reading Practice</h3>
                    <p className="text-slate-500">Read aloud and get instant feedback on your pronunciation.</p>
                </div>
            </div>
          </div>
        );
      
      case View.CHAT:
        return (
          <LiveSession 
            scenarioTitle={activeScenario?.title}
          />
        );
      
      case View.TEXT_CHAT:
        return <TextChat />;

      case View.PRACTICE:
        return <PracticeMode onSelectScenario={handleScenarioSelect} />;
      
      case View.READING:
        return <ReadingPractice />;

      case View.EXERCISES:
        return <SmartExercises />;

      case View.PROFILE:
        return <Profile />;
        
      default:
        return <div>Page not found</div>;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Navigation currentView={currentView} onNavigate={handleNavigate} />
      <main>
        {renderContent()}
      </main>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <ErrorBoundary>
      <I18nProvider>
        <AppContent />
      </I18nProvider>
    </ErrorBoundary>
  );
};

export default App;
