import { useState, useRef, useCallback, useEffect } from 'react';
import { LiveServerMessage, Modality } from '@google/genai';
import { createBlob, decode, decodeAudioData } from '../utils/audio';
import { ChatMessage, ConnectionState } from '../types';
import { ai, MODEL_IDS } from '../services/gemini';

export const useLiveApi = (systemInstruction: string = "You are a helpful English tutor.") => {
  const [connectionState, setConnectionState] = useState<ConnectionState>('disconnected');
  const [transcripts, setTranscripts] = useState<ChatMessage[]>([]);
  const [volume, setVolume] = useState(0);
  
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  
  const currentInputTranscriptionRef = useRef('');
  const currentOutputTranscriptionRef = useRef('');

  const disconnect = useCallback(() => {
    if (sessionPromiseRef.current) {
        sessionPromiseRef.current.then(session => session.close()).catch(() => {});
        sessionPromiseRef.current = null;
    }
    
    sourcesRef.current.forEach(source => {
        try { source.stop(); } catch(e) {}
    });
    sourcesRef.current.clear();

    if (inputAudioContextRef.current) {
        inputAudioContextRef.current.close();
        inputAudioContextRef.current = null;
    }
    if (outputAudioContextRef.current) {
        outputAudioContextRef.current.close();
        outputAudioContextRef.current = null;
    }

    if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
        streamRef.current = null;
    }

    setConnectionState('disconnected');
    setVolume(0);
  }, []);

  const connect = useCallback(async () => {
    try {
      setConnectionState('connecting');
      
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      inputAudioContextRef.current = inputCtx;
      outputAudioContextRef.current = outputCtx;
      nextStartTimeRef.current = 0;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      const config = {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
        },
        systemInstruction: systemInstruction,
        inputAudioTranscription: {},
        outputAudioTranscription: {},
      };

      // Use the centralized `ai` instance
      const sessionPromise = ai.live.connect({
        model: MODEL_IDS.LIVE,
        config,
        callbacks: {
          onopen: () => {
            console.log('Live session connected');
            setConnectionState('connected');
            
            const source = inputCtx.createMediaStreamSource(stream);
            inputSourceRef.current = source;
            
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;
            
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              
              let sum = 0;
              for(let i = 0; i < inputData.length; i++) sum += inputData[i] * inputData[i];
              const rms = Math.sqrt(sum / inputData.length);
              setVolume(Math.min(rms * 5, 1)); 
              
              const pcmBlob = createBlob(inputData, 16000);
              sessionPromise.then((session: any) => {
                 session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(processor);
            processor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const serverContent = message.serverContent;
            if (serverContent) {
                if (serverContent.outputTranscription?.text) {
                    currentOutputTranscriptionRef.current += serverContent.outputTranscription.text;
                }
                if (serverContent.inputTranscription?.text) {
                    currentInputTranscriptionRef.current += serverContent.inputTranscription.text;
                }
                
                if (serverContent.turnComplete) {
                    const userText = currentInputTranscriptionRef.current.trim();
                    const modelText = currentOutputTranscriptionRef.current.trim();
                    
                    if (userText || modelText) {
                        setTranscripts(prev => [
                            ...prev,
                            ...(userText ? [{ role: 'user', text: userText, timestamp: new Date() } as ChatMessage] : []),
                            ...(modelText ? [{ role: 'model', text: modelText, timestamp: new Date() } as ChatMessage] : [])
                        ]);
                    }
                    
                    currentInputTranscriptionRef.current = '';
                    currentOutputTranscriptionRef.current = '';
                }
                
                if (serverContent.interrupted) {
                    sourcesRef.current.forEach(source => {
                        source.stop();
                        sourcesRef.current.delete(source);
                    });
                    nextStartTimeRef.current = 0;
                }
            }

            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current) {
                const ctx = outputAudioContextRef.current;
                const audioBuffer = await decodeAudioData(
                    decode(base64Audio),
                    ctx,
                    24000,
                    1
                );
                
                const source = ctx.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(ctx.destination);
                
                source.onended = () => {
                    sourcesRef.current.delete(source);
                };
                
                const currentTime = ctx.currentTime;
                if (nextStartTimeRef.current < currentTime) {
                    nextStartTimeRef.current = currentTime;
                }
                
                source.start(nextStartTimeRef.current);
                nextStartTimeRef.current += audioBuffer.duration;
                sourcesRef.current.add(source);
            }
          },
          onclose: () => {
            console.log('Session closed');
            setConnectionState('disconnected');
          },
          onerror: (err) => {
            console.error('Session error:', err);
            setConnectionState('error');
          }
        }
      });
      
      sessionPromiseRef.current = sessionPromise;

    } catch (error) {
      console.error("Connection failed", error);
      setConnectionState('error');
    }
  }, [systemInstruction]);

  useEffect(() => {
    return () => {
        disconnect();
    };
  }, [disconnect]);

  return {
    connect,
    disconnect,
    connectionState,
    transcripts,
    volume
  };
};