import React, { useState, useRef } from 'react';
import { callGemini } from '../services/gemini';
import { userState } from '../services/state';
import { PromptTemplates } from '../services/prompts';

const TOPICS = ['Travel', 'Business', 'Daily Life', 'Technology', 'Food', 'Culture'];

const ReadingPractice: React.FC = () => {
  const [text, setText] = useState<string>('');
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [feedback, setFeedback] = useState<any>(null);
  const [loadingText, setLoadingText] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const userProfile = userState.get();

  const generateText = async (topic: string) => {
    setLoadingText(true);
    setFeedback(null);
    try {
      const responseText = await callGemini([
        { role: 'user', text: PromptTemplates.getReadingPrompt(userProfile.level, topic) }
      ]);
      setText(responseText || '');
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingText(false);
    }
  };

  const playText = () => {
    if (!text) return;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.9; // Slightly slower for clarity
    window.speechSynthesis.speak(utterance);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setFeedback(null);
    } catch (e) {
      console.error("Error accessing microphone", e);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      mediaRecorderRef.current.onstop = async () => {
        const audioBlob = new Blob(chunksRef.current, { type: 'audio/wav' });
        analyzePronunciation(audioBlob);
        
        // Stop all tracks
        mediaRecorderRef.current?.stream.getTracks().forEach(track => track.stop());
      };
    }
  };

  const analyzePronunciation = async (audioBlob: Blob) => {
    setIsAnalyzing(true);
    try {
      // Convert blob to base64
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        const base64data = (reader.result as string).split(',')[1];
        
        const prompt = `
          I am reading the following text: "${text}".
          Please evaluate my pronunciation, intonation, and speed.
          Give me a score out of 10.
          List specific words I mispronounced.
          IMPORTANT: Return ONLY JSON: { "score": number, "feedback": "string", "mispronouncedWords": ["string"] }
        `;

        // Use multimodal parts structure supported by our updated api/gemini.ts
        const responseText = await callGemini([
          {
            role: 'user',
            parts: [
              { text: prompt },
              { inlineData: { mimeType: 'audio/wav', data: base64data } }
            ]
          }
        ]);

        const cleanedText = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
        const result = JSON.parse(cleanedText || '{}');
        setFeedback(result);
        
        if (result.score) {
             // Update stats loosely based on reading
             userState.updateStats(2); 
        }
      };
    } catch (e) {
      console.error(e);
      setFeedback({ error: "Could not analyze audio. Please try again." });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h2 className="text-2xl font-bold text-slate-900">Reading & Pronunciation</h2>
        <p className="text-slate-500">Read aloud and get AI feedback.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Sidebar: Topics */}
        <div className="md:col-span-1 space-y-3">
           <h3 className="font-semibold text-slate-700 mb-2">Choose a Topic</h3>
           {TOPICS.map(topic => (
             <button
               key={topic}
               onClick={() => generateText(topic)}
               disabled={loadingText}
               className="w-full text-left px-4 py-3 rounded-xl bg-white border border-slate-200 hover:border-indigo-500 hover:bg-indigo-50 transition-all text-slate-700 font-medium text-sm"
             >
               {topic}
             </button>
           ))}
        </div>

        {/* Main Area */}
        <div className="md:col-span-2">
           <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 min-h-[300px] flex flex-col">
              {loadingText ? (
                  <div className="flex-1 flex items-center justify-center text-slate-400 animate-pulse">
                      Generating text...
                  </div>
              ) : text ? (
                  <>
                    <div className="flex-1 mb-8">
                        <p className="text-lg leading-relaxed text-slate-800 font-medium">{text}</p>
                        <button onClick={playText} className="mt-4 text-indigo-600 text-sm font-semibold flex items-center hover:underline">
                            <svg className="w-4 h-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                            </svg>
                            Listen to AI
                        </button>
                    </div>

                    <div className="flex flex-col items-center">
                        <button
                            onClick={isRecording ? stopRecording : startRecording}
                            disabled={isAnalyzing}
                            className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${
                                isRecording 
                                ? 'bg-red-500 shadow-lg shadow-red-200 animate-pulse' 
                                : 'bg-indigo-600 shadow-lg shadow-indigo-200 hover:bg-indigo-700'
                            }`}
                        >
                            {isAnalyzing ? (
                                <svg className="w-6 h-6 text-white animate-spin" fill="none" viewBox="0 0 24 24">
                                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                            ) : isRecording ? (
                                <div className="w-6 h-6 bg-white rounded-sm" />
                            ) : (
                                <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                                </svg>
                            )}
                        </button>
                        <p className="mt-3 text-sm text-slate-500">
                            {isAnalyzing ? "Analyzing..." : isRecording ? "Recording..." : "Tap to Record"}
                        </p>
                    </div>
                  </>
              ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                      <div className="text-4xl mb-3">📖</div>
                      <p>Select a topic to generate a reading passage.</p>
                  </div>
              )}
           </div>

           {/* Feedback Area */}
           {feedback && (
               <div className="mt-6 bg-slate-50 rounded-xl border border-slate-200 p-6">
                   <div className="flex items-center justify-between mb-4">
                       <h3 className="font-bold text-slate-800">Feedback</h3>
                       <div className="flex items-center">
                           <span className="text-sm text-slate-500 mr-2">Score:</span>
                           <span className={`text-xl font-bold ${
                               feedback.score >= 8 ? 'text-green-600' : feedback.score >= 5 ? 'text-yellow-600' : 'text-red-600'
                           }`}>{feedback.score}/10</span>
                       </div>
                   </div>
                   <p className="text-slate-700 mb-4">{feedback.feedback}</p>
                   
                   {feedback.mispronouncedWords && feedback.mispronouncedWords.length > 0 && (
                       <div>
                           <p className="text-sm font-semibold text-slate-500 mb-2">Words to practice:</p>
                           <div className="flex flex-wrap gap-2">
                               {feedback.mispronouncedWords.map((w: string, i: number) => (
                                   <span key={i} className="px-2 py-1 bg-red-100 text-red-700 rounded text-sm">
                                       {w}
                                   </span>
                               ))}
                           </div>
                       </div>
                   )}
               </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default ReadingPractice;