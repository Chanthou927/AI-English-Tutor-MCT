import React, { useEffect, useRef } from 'react';
import { useLiveApi } from '../hooks/useLiveApi';
import { ConnectionState } from '../types';
import { userState } from '../services/state';
import { PromptTemplates } from '../services/prompts';

interface LiveSessionProps {
  scenarioTitle?: string;
}

const LiveSession: React.FC<LiveSessionProps> = ({ 
  scenarioTitle 
}) => {
  const profile = userState.get();
  const systemInstruction = PromptTemplates.getSystemInstruction(profile, scenarioTitle ? {
      id: 'custom',
      title: scenarioTitle,
      description: '',
      icon: '',
      difficulty: profile.level,
      systemInstruction: `You are acting as a partner in a scenario titled: "${scenarioTitle}".`
  } : undefined);

  const { connect, disconnect, connectionState, transcripts, volume } = useLiveApi(systemInstruction);
  const transcriptContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (transcriptContainerRef.current) {
      transcriptContainerRef.current.scrollTop = transcriptContainerRef.current.scrollHeight;
    }
  }, [transcripts]);

  const isActive = connectionState === 'connected';
  const isError = connectionState === 'error';
  
  // Calculate dynamic styles for visualization
  const pulseScale = 1 + Math.min(volume, 1) * 0.8;
  const opacity = 0.3 + Math.min(volume, 1) * 0.5;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 h-[calc(100vh-4rem)] flex flex-col">
      <div className="mb-6 text-center">
        <h2 className="text-2xl font-bold text-slate-900">
          {scenarioTitle ? `Practice: ${scenarioTitle}` : 'Conversation Practice'}
        </h2>
        <p className="text-slate-500">Speak naturally with your AI tutor.</p>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center min-h-0 relative bg-gradient-to-b from-slate-50 to-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        
        {/* Ambient Background Animation */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
           {isActive && (
               <>
                <div className="absolute w-96 h-96 bg-indigo-400 rounded-full mix-blend-multiply filter blur-3xl transition-all duration-100"
                     style={{ 
                       transform: `scale(${pulseScale}) translate(-20px, -20px)`,
                       opacity: opacity 
                     }}></div>
                <div className="absolute w-96 h-96 bg-purple-400 rounded-full mix-blend-multiply filter blur-3xl transition-all duration-150"
                     style={{ 
                       transform: `scale(${pulseScale * 0.9}) translate(20px, 20px)`,
                       opacity: opacity 
                     }}></div>
                 <div className="absolute w-80 h-80 bg-blue-300 rounded-full mix-blend-multiply filter blur-3xl transition-all duration-200"
                     style={{ 
                       transform: `scale(${pulseScale * 1.1})`,
                       opacity: opacity * 0.8
                     }}></div>
               </>
           )}
        </div>

        {/* Main Interaction Button */}
        <div className="z-10 relative mb-8 flex flex-col items-center">
          <button
            onClick={isActive ? disconnect : connect}
            disabled={connectionState === 'connecting'}
            className={`relative group w-32 h-32 rounded-full flex items-center justify-center transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-offset-2 ${
              isActive 
                ? 'bg-white ring-4 ring-red-100 text-red-500 hover:scale-105 shadow-xl' 
                : 'bg-indigo-600 ring-4 ring-indigo-100 text-white hover:bg-indigo-700 hover:scale-105 shadow-xl shadow-indigo-200'
            } ${connectionState === 'connecting' ? 'opacity-90 cursor-wait' : ''}`}
          >
            {isActive && (
              <span className="absolute w-full h-full rounded-full border-4 border-red-500 opacity-20 animate-ping"></span>
            )}
            
            {connectionState === 'connecting' ? (
               <svg className="animate-spin h-10 w-10" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : isActive ? (
              <div className="flex flex-col items-center">
                 <div className="w-8 h-8 bg-red-500 rounded shadow-sm mb-1"></div>
              </div>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            )}
          </button>
          
          <div className="mt-6 flex flex-col items-center space-y-1">
            <p className={`text-lg font-semibold transition-colors duration-300 ${isActive ? 'text-slate-800' : 'text-slate-600'}`}>
                {connectionState === 'connecting' ? 'Establishing Connection...' : isActive ? 'Listening...' : 'Tap Mic to Start'}
            </p>
            {isActive && (
                <span className="text-xs font-medium text-red-500 bg-red-50 px-2 py-0.5 rounded-full border border-red-100 animate-pulse">
                    LIVE
                </span>
            )}
          </div>
        </div>
        
        {isError && (
            <div className="absolute top-6 mx-auto bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm font-medium flex items-center shadow-sm max-w-md">
                <svg className="w-5 h-5 mr-2 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Connection failed. Please check your API key.
            </div>
        )}
      </div>

      <div className="h-1/3 mt-6 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
            <h3 className="text-sm font-semibold text-slate-700 flex items-center">
                <span className="w-2 h-2 bg-slate-400 rounded-full mr-2"></span>
                Live Transcript
            </h3>
            {transcripts.length > 0 && (
                <span className="text-xs text-slate-400">{transcripts.length} messages</span>
            )}
        </div>
        <div ref={transcriptContainerRef} className="flex-1 overflow-y-auto p-5 space-y-4 scroll-smooth">
            {transcripts.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400">
                    <p className="text-sm italic">Conversation will appear here...</p>
                </div>
            ) : (
                transcripts.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in-up`}>
                        <div className={`max-w-[85%] rounded-2xl px-5 py-3 text-sm shadow-sm ${
                            msg.role === 'user' 
                            ? 'bg-indigo-600 text-white rounded-tr-sm' 
                            : 'bg-slate-100 text-slate-800 rounded-tl-sm'
                        }`}>
                            {msg.text}
                        </div>
                    </div>
                ))
            )}
        </div>
      </div>
    </div>
  );
};

export default LiveSession;