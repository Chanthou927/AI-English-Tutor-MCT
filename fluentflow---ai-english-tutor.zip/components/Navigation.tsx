
import React, { useState } from 'react';
import { View } from '../types';
import { useTranslation } from '../contexts/I18nContext';
import { Language } from '../i18n/locales';

interface NavigationProps {
  currentView: View;
  onNavigate: (view: View) => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, onNavigate }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { t, language, setLanguage } = useTranslation();

  const navItems = [
    { id: View.HOME, label: t('nav.home') },
    { id: View.PRACTICE, label: t('nav.practice') },
    { id: View.CHAT, label: t('nav.chat') },
    { id: View.TEXT_CHAT, label: t('nav.textChat') },
    { id: View.READING, label: t('nav.reading') },
    { id: View.EXERCISES, label: t('nav.quiz') },
    { id: View.PROFILE, label: t('nav.profile') },
  ];

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50" aria-label="Main navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div 
              className="flex-shrink-0 flex items-center cursor-pointer" 
              onClick={() => onNavigate(View.HOME)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && onNavigate(View.HOME)}
            >
              <div className="h-8 w-8 bg-indigo-600 rounded-lg flex items-center justify-center mr-2" aria-hidden="true">
                <svg className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
              <span className="font-bold text-xl text-slate-800">FluentFlow</span>
            </div>
            <div className="hidden lg:ml-8 lg:flex lg:space-x-6">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  aria-current={currentView === item.id ? 'page' : undefined}
                  className={`${
                    currentView === item.id
                      ? 'border-indigo-500 text-gray-900'
                      : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  } inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium transition-colors duration-200`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
          
          <div className="flex items-center">
            {/* Language Switcher */}
            <div className="hidden md:flex items-center mr-4 space-x-2">
                <button 
                    onClick={() => setLanguage('en')}
                    className={`text-xs font-bold px-2 py-1 rounded ${language === 'en' ? 'bg-slate-200' : 'text-slate-400'}`}
                    aria-label="Switch to English"
                >
                    EN
                </button>
                <button 
                    onClick={() => setLanguage('es')}
                    className={`text-xs font-bold px-2 py-1 rounded ${language === 'es' ? 'bg-slate-200' : 'text-slate-400'}`}
                    aria-label="Cambiar a Español"
                >
                    ES
                </button>
            </div>

            {/* Mobile menu button */}
            <div className="-mr-2 flex items-center lg:hidden">
                <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
                aria-expanded={isMobileMenuOpen}
                aria-label="Open main menu"
                >
                <svg className={`${isMobileMenuOpen ? 'hidden' : 'block'} h-6 w-6`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <svg className={`${isMobileMenuOpen ? 'block' : 'hidden'} h-6 w-6`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
                </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`${isMobileMenuOpen ? 'block' : 'hidden'} lg:hidden`}>
        <div className="pt-2 pb-3 space-y-1 bg-white shadow-lg absolute w-full z-50">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onNavigate(item.id);
                setIsMobileMenuOpen(false);
              }}
              className={`${
                currentView === item.id
                  ? 'bg-indigo-50 border-indigo-500 text-indigo-700'
                  : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700'
              } block pl-3 pr-4 py-2 border-l-4 text-base font-medium w-full text-left`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
