
import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { callGemini, globalRateLimiter, withRetry, GeminiError } from '../services/gemini';
import { userState } from '../services/state';
import { PromptTemplates } from '../services/prompts';

const TextChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = async () => {
    const userText = input.trim();
    if (!userText || isLoading) return;

    if (!globalRateLimiter.check()) {
      setError("You are sending messages too quickly. Please wait a moment.");
      return;
    }

    setError(null);
    const newMessages = [...messages, { role: 'user', text: userText, timestamp: new Date() } as ChatMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
        const profile = userState.get();
        const systemInstruction = PromptTemplates.getSystemInstruction(profile);
        
        // Prepare payload for backend: needs simple { role, text } objects
        const backendMessages = newMessages.map(m => ({ role: m.role, text: m.text }));

        const responseText = await withRetry(async () => {
            return await callGemini(backendMessages, systemInstruction);
        });
        
        setMessages(prev => [...prev, { 
            role: 'model', 
            text: responseText, 
            timestamp: new Date() 
        }]);

    } catch (e: any) {
        console.error(e);
        const errorMessage = e instanceof GeminiError 
          ? e.message 
          : e.message || "Sorry, I encountered an error connecting to the AI.";
          
        setMessages(prev => [...prev, { 
          role: 'model', 
          text: `[Error]: ${errorMessage}`, 
          timestamp: new Date() 
        }]);
    } finally {
        setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const endSession = async () => {
      // Logic for analysis would ideally move to backend too, 
      // but for now we focus on the chat interaction.
      alert("Session ended.");
      setMessages([]);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 h-[calc(100vh-4rem)] flex flex-col">
      <div className="mb-6 flex justify-between items-center">
        <div>
            <h2 className="text-2xl font-bold text-slate-900">Text Chat</h2>
            <p className="text-slate-500 text-sm">AI adapts to your level.</p>
        </div>
        {messages.length > 2 && (
            <button 
                onClick={endSession}
                disabled={isLoading}
                className="text-sm bg-indigo-50 text-indigo-700 px-3 py-1 rounded-lg hover:bg-indigo-100 font-medium"
            >
                End Session
            </button>
        )}
      </div>

      <div className="flex-1 flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden relative">
        
        {error && (
          <div className="absolute top-0 left-0 right-0 bg-red-50 text-red-600 px-4 py-2 text-sm text-center border-b border-red-100 z-10">
            {error}
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
            {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-2">
                    <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center text-2xl mb-2">💬</div>
                    <p>Start the conversation!</p>
                </div>
            ) : (
                messages.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] rounded-2xl px-5 py-3 text-sm shadow-sm ${
                            msg.role === 'user' 
                            ? 'bg-indigo-600 text-white rounded-br-none' 
                            : msg.text.startsWith('[Error]')
                              ? 'bg-red-50 text-red-800 border border-red-200 rounded-bl-none'
                              : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none'
                        }`}>
                            <p className="whitespace-pre-wrap">{msg.text}</p>
                        </div>
                    </div>
                ))
            )}
             {isLoading && (
                <div className="flex justify-start">
                    <div className="bg-white border border-slate-200 text-slate-500 rounded-2xl rounded-bl-none px-5 py-3 shadow-sm">
                       <div className="flex space-x-1">
                           <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                           <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                           <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                       </div>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-white border-t border-slate-100">
            <div className="flex items-end space-x-2 max-w-4xl mx-auto">
                <div className="flex-1 bg-slate-100 rounded-xl overflow-hidden focus-within:ring-2 focus-within:ring-indigo-500 focus-within:bg-white transition-all">
                    <textarea
                        value={input}
                        onChange={(e) => {
                            setInput(e.target.value);
                            if (error) setError(null);
                        }}
                        onKeyDown={handleKeyDown}
                        placeholder="Type a message..."
                        className="w-full p-3 bg-transparent border-none focus:ring-0 resize-none text-slate-800 placeholder-slate-400 max-h-32"
                        rows={1}
                        style={{ minHeight: '48px' }}
                    />
                </div>
                <button
                    onClick={handleSend}
                    disabled={!input.trim() || isLoading}
                    className="p-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-md flex-shrink-0"
                >
                    <svg className="w-5 h-5 transform rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default TextChat;
