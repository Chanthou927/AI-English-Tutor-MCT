import React from 'react';
import { Scenario } from '../types';

interface PracticeModeProps {
  onSelectScenario: (scenario: Scenario) => void;
}

const scenarios: Scenario[] = [
  {
    id: 'coffee-shop',
    title: 'At the Coffee Shop',
    description: 'Order your favorite drink and make small talk with the barista.',
    difficulty: 'Beginner',
    icon: '☕',
    systemInstruction: "You are a friendly barista at a cozy coffee shop. The user is a customer ordering a drink. Start by greeting them and asking what they would like. Keep the conversation light and helpful.",
  },
  {
    id: 'job-interview',
    title: 'Job Interview',
    description: 'Practice answering common interview questions for a software role.',
    difficulty: 'Advanced',
    icon: '💼',
    systemInstruction: "You are a hiring manager conducting a job interview. The user is a candidate. Ask professional questions about their experience, strengths, and weaknesses. Provide constructive feedback if asked.",
  },
  {
    id: 'asking-directions',
    title: 'Asking for Directions',
    description: 'You are lost in a new city. Ask a local for help finding the museum.',
    difficulty: 'Beginner',
    icon: '🗺️',
    systemInstruction: "You are a helpful local pedestrian in New York City. The user is a tourist asking for directions. Give clear, step-by-step directions and maybe recommend a nearby landmark.",
  },
  {
    id: 'hotel-checkin',
    title: 'Hotel Check-in',
    description: 'Check into your hotel room and ask about amenities.',
    difficulty: 'Intermediate',
    icon: '🏨',
    systemInstruction: "You are a hotel receptionist. The user is checking in. Ask for their name and ID. Explain the hotel amenities like the pool and breakfast hours politely.",
  },
  {
    id: 'doctor-visit',
    title: 'Doctor\'s Appointment',
    description: 'Explain your symptoms to a doctor and get advice.',
    difficulty: 'Intermediate',
    icon: '🩺',
    systemInstruction: "You are a caring doctor. The user is a patient describing their symptoms. Ask clarifying questions to understand their condition and offer medical advice or a prescription.",
  },
  {
    id: 'movie-discussion',
    title: 'Discussing a Movie',
    description: 'Talk about a recent movie you watched with a friend.',
    difficulty: 'Advanced',
    icon: '🎬',
    systemInstruction: "You are a movie enthusiast friend. The user wants to discuss a recent film. Share your opinions, ask about their favorite scenes, and keep the conversation engaging and casual.",
  }
];

const PracticeMode: React.FC<PracticeModeProps> = ({ onSelectScenario }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-slate-900">Practice Scenarios</h2>
        <p className="mt-2 text-slate-600">Select a situation to start a roleplay conversation with AI.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {scenarios.map((scenario) => (
          <div 
            key={scenario.id} 
            onClick={() => onSelectScenario(scenario)}
            className="group bg-white rounded-xl border border-slate-200 hover:border-indigo-500 hover:shadow-lg transition-all duration-200 cursor-pointer overflow-hidden"
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <span className="text-4xl p-2 bg-slate-50 rounded-lg">{scenario.icon}</span>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  scenario.difficulty === 'Beginner' ? 'bg-green-100 text-green-800' :
                  scenario.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {scenario.difficulty}
                </span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2 group-hover:text-indigo-600 transition-colors">
                {scenario.title}
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                {scenario.description}
              </p>
            </div>
            <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
               <span className="text-xs text-slate-500 font-medium">Roleplay Mode</span>
               <svg className="w-5 h-5 text-indigo-500 transform group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
               </svg>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PracticeMode;