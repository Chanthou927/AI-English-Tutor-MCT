import React, { useState, useEffect } from 'react';
import { callGemini } from '../services/gemini';
import { userState } from '../services/state';
import { PromptTemplates } from '../services/prompts';

interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const SmartExercises: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);
  const [completed, setCompleted] = useState(false);

  const generateQuiz = async () => {
    setLoading(true);
    setCompleted(false);
    setCurrentIndex(0);
    setScore(0);
    setQuestions([]);
    
    try {
      const userProfile = userState.get();
      // We wrap the prompt in a message structure for callGemini
      const prompt = PromptTemplates.getQuizPrompt(userProfile);
      
      // We append instructions to ensure JSON format as the backend 
      // might not support dynamic responseSchema injection via this simple wrapper yet
      const jsonInstruction = " IMPORTANT: Return the response as raw JSON only, without Markdown formatting or code blocks.";
      
      const responseText = await callGemini(
        [{ role: 'user', text: prompt + jsonInstruction }]
      );
      
      // Clean up potential markdown code blocks if the model adds them
      const cleanedText = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
      const data = JSON.parse(cleanedText || '[]');
      setQuestions(data);
    } catch (e) {
      console.error("Failed to generate quiz", e);
    } finally {
      setLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    // Don't auto load, let user click start to save API calls
  }, []);

  const handleOptionSelect = (index: number) => {
    if (selectedOption !== null) return; // Prevent changing answer
    setSelectedOption(index);
    setShowExplanation(true);
    if (index === questions[currentIndex].correctIndex) {
        setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
        setCurrentIndex(prev => prev + 1);
        setSelectedOption(null);
        setShowExplanation(false);
    } else {
        setCompleted(true);
        userState.updateStats(5); // 5 minutes credit for a quiz
    }
  };

  if (loading) {
      return (
          <div className="flex flex-col items-center justify-center h-96">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
              <p className="text-slate-500">Generating custom exercises from your mistakes...</p>
          </div>
      );
  }

  if (questions.length === 0 && !completed) {
      return (
          <div className="max-w-2xl mx-auto px-4 py-12 text-center">
              <div className="w-20 h-20 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center text-4xl mx-auto mb-6">
                  🧠
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-3">Smart Exercises</h2>
              <p className="text-slate-600 mb-8">
                  AI analyzes your recent conversation mistakes and vocabulary to create a personalized quiz just for you.
              </p>
              <button 
                onClick={generateQuiz}
                className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-all shadow-lg hover:shadow-indigo-200"
              >
                  Generate My Quiz
              </button>
          </div>
      );
  }

  if (completed) {
      return (
          <div className="max-w-lg mx-auto px-4 py-12 text-center bg-white rounded-2xl border border-slate-200 shadow-sm mt-8">
              <div className="text-6xl mb-4">🎉</div>
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Quiz Completed!</h2>
              <p className="text-slate-600 mb-6">You scored {score} out of {questions.length}</p>
              <button 
                onClick={generateQuiz}
                className="text-indigo-600 font-medium hover:underline"
              >
                  Try another quiz
              </button>
          </div>
      );
  }

  const currentQuestion = questions[currentIndex];

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
            <span className="text-sm font-medium text-slate-500">Question {currentIndex + 1} of {questions.length}</span>
            <span className="text-sm font-medium text-slate-900">Score: {score}</span>
        </div>

        <div className="w-full bg-slate-200 h-2 rounded-full mb-8 overflow-hidden">
            <div 
                className="bg-indigo-600 h-full transition-all duration-300" 
                style={{ width: `${((currentIndex) / questions.length) * 100}%` }} 
            />
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 md:p-8">
                <h3 className="text-xl font-bold text-slate-900 mb-6 leading-relaxed">
                    {currentQuestion.question}
                </h3>
                
                <div className="space-y-3">
                    {currentQuestion.options.map((option, idx) => {
                        let btnClass = "border-slate-200 hover:bg-slate-50";
                        if (selectedOption !== null) {
                            if (idx === currentQuestion.correctIndex) btnClass = "bg-green-50 border-green-200 text-green-800";
                            else if (idx === selectedOption) btnClass = "bg-red-50 border-red-200 text-red-800";
                            else btnClass = "border-slate-200 opacity-50";
                        }

                        return (
                            <button
                                key={idx}
                                onClick={() => handleOptionSelect(idx)}
                                disabled={selectedOption !== null}
                                className={`w-full text-left p-4 rounded-xl border-2 font-medium transition-all ${btnClass}`}
                            >
                                {option}
                            </button>
                        );
                    })}
                </div>

                {showExplanation && (
                    <div className="mt-6 p-4 bg-indigo-50 rounded-xl border border-indigo-100 text-indigo-900 text-sm animate-fade-in">
                        <strong>Explanation:</strong> {currentQuestion.explanation}
                    </div>
                )}
            </div>
            
            <div className="bg-slate-50 p-4 flex justify-end border-t border-slate-100">
                <button
                    onClick={handleNext}
                    disabled={selectedOption === null}
                    className="px-6 py-2 bg-slate-900 text-white rounded-lg font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-800 transition-colors"
                >
                    {currentIndex === questions.length - 1 ? "Finish" : "Next Question"}
                </button>
            </div>
        </div>
    </div>
  );
};

export default SmartExercises;