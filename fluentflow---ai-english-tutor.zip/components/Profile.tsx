
import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { userState } from '../services/state';
import { UserProfile, ProficiencyLevel } from '../types';

const Profile: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile>(userState.get());

  const handleLevelChange = (level: ProficiencyLevel) => {
    userState.setLevel(level);
    setProfile(userState.get());
  };

  // Mock data for chart - in a full app this would come from stats history
  const data = [
    { name: 'Mon', minutes: 20 },
    { name: 'Tue', minutes: 35 },
    { name: 'Wed', minutes: 15 },
    { name: 'Thu', minutes: 45 },
    { name: 'Fri', minutes: 30 + (profile.stats.totalMinutes % 30) }, 
    { name: 'Sat', minutes: 10 },
    { name: 'Sun', minutes: 5 },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
        <div className="p-8 flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
          <div className="h-24 w-24 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 flex items-center justify-center text-white text-3xl font-bold shrink-0">
            {profile.name.charAt(0)}
          </div>
          <div className="flex-1 text-center md:text-left">
            <div className="flex flex-col md:flex-row items-center justify-between">
                <h2 className="text-2xl font-bold text-slate-900">{profile.name}</h2>
                <div className="mt-2 md:mt-0 flex space-x-2">
                    {(['Beginner', 'Intermediate', 'Advanced'] as ProficiencyLevel[]).map(l => (
                        <button 
                            key={l}
                            onClick={() => handleLevelChange(l)}
                            className={`text-xs px-3 py-1 rounded-full border ${
                                profile.level === l 
                                ? 'bg-indigo-600 text-white border-indigo-600' 
                                : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-300'
                            }`}
                        >
                            {l}
                        </button>
                    ))}
                </div>
            </div>
            <p className="text-slate-500 mt-1">Level: <span className="font-semibold text-indigo-600">{profile.level}</span></p>
            
            <div className="flex mt-6 justify-center md:justify-start space-x-8">
                <div>
                    <p className="text-2xl font-bold text-slate-900">{Math.round(profile.stats.totalMinutes / 60 * 10) / 10}h</p>
                    <p className="text-xs text-slate-400 uppercase tracking-wide font-semibold">Practice</p>
                </div>
                <div>
                    <p className="text-2xl font-bold text-slate-900">{profile.stats.totalSessions}</p>
                    <p className="text-xs text-slate-400 uppercase tracking-wide font-semibold">Sessions</p>
                </div>
                <div>
                    <p className="text-2xl font-bold text-slate-900">🔥 {profile.stats.streakDays}</p>
                    <p className="text-xs text-slate-400 uppercase tracking-wide font-semibold">Streak</p>
                </div>
            </div>
          </div>
        </div>
        
        {/* Activity Chart Area */}
        <div className="px-8 pb-6 border-t border-slate-50 pt-6">
             <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wide mb-4">Activity (Minutes)</h3>
             <div className="h-48 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12}} />
                        <Tooltip 
                            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                        />
                        <Bar dataKey="minutes" fill="#6366f1" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
             </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Vocabulary Bank */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-96 flex flex-col">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-slate-800">📚 Vocabulary Bank</h3>
                <span className="text-xs font-medium bg-green-100 text-green-800 px-2 py-1 rounded-full">
                    {profile.memory.vocabulary.length} words
                </span>
            </div>
            <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                {profile.memory.vocabulary.length === 0 ? (
                    <p className="text-slate-400 text-sm text-center mt-10">No words saved yet. Start chatting!</p>
                ) : (
                    profile.memory.vocabulary.map((v, i) => (
                        <div key={i} className="p-3 bg-slate-50 rounded-lg border border-slate-100 hover:border-indigo-100 transition-colors">
                            <p className="font-bold text-indigo-700">{v.word}</p>
                            <p className="text-xs text-slate-600 italic">{v.definition}</p>
                        </div>
                    ))
                )}
            </div>
        </div>

        {/* Recent Mistakes */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-96 flex flex-col">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-slate-800">⚠️ Areas to Improve</h3>
                <span className="text-xs font-medium bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">
                    {profile.memory.recentMistakes.length} items
                </span>
            </div>
            <div className="flex-1 overflow-y-auto space-y-3 pr-2">
                {profile.memory.recentMistakes.length === 0 ? (
                    <p className="text-slate-400 text-sm text-center mt-10">Great job! No mistakes recorded recently.</p>
                ) : (
                    profile.memory.recentMistakes.map((m, i) => (
                        <div key={i} className="p-3 bg-red-50 rounded-lg border border-red-100">
                            <div className="flex items-center space-x-2 mb-1">
                                <span className="text-xs line-through text-red-400">{m.original}</span>
                                <span className="text-xs text-slate-400">→</span>
                                <span className="text-xs font-bold text-green-600">{m.correction}</span>
                            </div>
                            <p className="text-xs text-slate-600">{m.explanation}</p>
                        </div>
                    ))
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
