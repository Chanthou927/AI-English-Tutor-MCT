import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Navigation from '../Navigation';
import { View } from '../../types';
import { I18nProvider } from '../../contexts/I18nContext';

declare const jest: any;
declare const describe: any;
declare const it: any;
declare const expect: any;

const renderWithProviders = (ui: React.ReactElement) => {
  return render(
    <I18nProvider>
      {ui}
    </I18nProvider>
  );
};

describe('Navigation Component', () => {
  it('renders navigation items', () => {
    const handleNavigate = jest.fn();
    renderWithProviders(
      <Navigation currentView={View.HOME} onNavigate={handleNavigate} />
    );

    expect(screen.getByText('Home')).toBeInTheDocument();
    expect(screen.getByText('Scenarios')).toBeInTheDocument();
    expect(screen.getByText('Profile')).toBeInTheDocument();
  });

  it('calls onNavigate when item is clicked', () => {
    const handleNavigate = jest.fn();
    renderWithProviders(
      <Navigation currentView={View.HOME} onNavigate={handleNavigate} />
    );

    fireEvent.click(screen.getByText('Scenarios'));
    expect(handleNavigate).toHaveBeenCalledWith(View.PRACTICE);
  });

  it('highlights the active view', () => {
    const handleNavigate = jest.fn();
    renderWithProviders(
      <Navigation currentView={View.CHAT} onNavigate={handleNavigate} />
    );

    const chatButton = screen.getByText('Live Voice');
    // Check for class that indicates active state (simplified check)
    expect(chatButton.className).toContain('border-indigo-500');
  });
});