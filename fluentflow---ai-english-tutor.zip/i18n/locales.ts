
export const resources = {
  en: {
    translation: {
      nav: {
        home: 'Home',
        practice: 'Practice',
        chat: 'AI Voice',
        textChat: 'AI Chat',
        reading: 'Reading',
        quiz: 'Exercises',
        profile: 'Profile',
      },
      home: {
        title: 'Master English with',
        subtitle: 'Live AI',
        description: 'Experience real-time voice conversations with an advanced AI tutor. Improve your pronunciation, fluency, and confidence instantly.',
        ctaPrimary: 'Start Talking Now',
        ctaSecondary: 'Test Pronunciation',
      },
      common: {
        loading: 'Loading...',
        error: 'Something went wrong',
        retry: 'Retry',
      }
    }
  },
  es: {
    translation: {
      nav: {
        home: 'Inicio',
        practice: 'Práctica',
        chat: 'Voz IA',
        textChat: 'Chat IA',
        reading: 'Lectura',
        quiz: 'Ejercicios',
        profile: 'Perfil',
      },
      home: {
        title: 'Domina el inglés con',
        subtitle: 'IA en Vivo',
        description: 'Experimenta conversaciones de voz en tiempo real con un tutor de IA avanzado. Mejora tu pronunciación, fluidez y confianza al instante.',
        ctaPrimary: 'Hablar Ahora',
        ctaSecondary: 'Probar Pronunciación',
      },
      common: {
        loading: 'Cargando...',
        error: 'Algo salió mal',
        retry: 'Reintentar',
      }
    }
  }
};

export type Language = keyof typeof resources;