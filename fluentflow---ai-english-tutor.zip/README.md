# FluentFlow - AI English Tutor

## Security & Deployment Note

This application currently runs entirely client-side for demonstration purposes. The Gemini API key is accessed via `process.env.API_KEY`.

### Production Deployment
When deploying to production, you should **never** expose your API key in the frontend code.

1.  **Backend Proxy**: Move the `services/gemini.ts` logic to a secure backend server (e.g., Node.js Express, Next.js API Route, or AWS Lambda).
2.  **Environment Variables**: Store `GEMINI_API_KEY` in your server's environment variables.
3.  **Authentication**: Add user authentication (OAuth, etc.) to your backend endpoints.
4.  **Rate Limiting**: Enforce rate limits on the server side (e.g., using Redis) to prevent abuse, as the current client-side rate limiter can be bypassed.

## Setup

1. Copy `.env.example` to `.env`.
2. Add your Google Gemini API Key.
3. Run the development server.
