
import { UserProfile, Mistake, Vocabulary, ProficiencyLevel } from '../types';

const STORAGE_KEY = 'fluentflow_user_state_v1';

const DEFAULT_STATE: UserProfile = {
  name: 'Guest Learner',
  level: 'Intermediate',
  objectives: ['Improve fluency', 'Expand vocabulary'],
  stats: {
    totalSessions: 0,
    totalMinutes: 0,
    streakDays: 0,
    lastActive: Date.now(),
  },
  memory: {
    recentMistakes: [],
    vocabulary: [],
  }
};

export const userState = {
  get(): UserProfile {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? { ...DEFAULT_STATE, ...JSON.parse(stored) } : DEFAULT_STATE;
    } catch {
      return DEFAULT_STATE;
    }
  },

  save(profile: UserProfile) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  },

  updateStats(minutes: number) {
    const profile = this.get();
    profile.stats.totalSessions += 1;
    profile.stats.totalMinutes += minutes;
    profile.stats.lastActive = Date.now();
    this.save(profile);
  },

  addMistake(mistake: Omit<Mistake, 'id' | 'timestamp'>) {
    const profile = this.get();
    const newMistake: Mistake = {
      ...mistake,
      id: crypto.randomUUID(),
      timestamp: Date.now()
    };
    // Keep last 50 mistakes
    profile.memory.recentMistakes = [newMistake, ...profile.memory.recentMistakes].slice(0, 50);
    this.save(profile);
  },

  addVocabulary(vocab: Omit<Vocabulary, 'timestamp'>) {
    const profile = this.get();
    // Avoid duplicates
    if (profile.memory.vocabulary.some(v => v.word.toLowerCase() === vocab.word.toLowerCase())) return;
    
    const newVocab: Vocabulary = {
      ...vocab,
      timestamp: Date.now()
    };
    profile.memory.vocabulary = [newVocab, ...profile.memory.vocabulary].slice(0, 50);
    this.save(profile);
  },
  
  setLevel(level: ProficiencyLevel) {
    const profile = this.get();
    profile.level = level;
    this.save(profile);
  }
};
