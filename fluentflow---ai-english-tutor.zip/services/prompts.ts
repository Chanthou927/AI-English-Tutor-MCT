
import { UserProfile, Scenario } from '../types';

export const PromptTemplates = {
  /**
   * Generates the core system instruction for the AI Tutor.
   * Injects user level, recent mistakes, and known vocabulary to personalize the session.
   */
  getSystemInstruction(profile: UserProfile, scenario?: Scenario): string {
    const baseIdentity = scenario 
      ? scenario.systemInstruction 
      : "You are a professional, encouraging, and highly skilled English tutor.";

    const levelContext = `The user's proficiency level is: ${profile.level}. Adjust your vocabulary and speaking speed accordingly.`;

    let memoryContext = "";
    if (profile.memory.recentMistakes.length > 0) {
      const mistakes = profile.memory.recentMistakes.slice(0, 3).map(m => `"${m.original}" (should be "${m.correction}")`).join(", ");
      memoryContext += `\nBe aware the user recently made these mistakes: ${mistakes}. If they make them again, gently correct them.`;
    }

    if (profile.memory.vocabulary.length > 0) {
      const vocab = profile.memory.vocabulary.slice(0, 5).map(v => v.word).join(", ");
      memoryContext += `\nEncourage the user to use these words they learned recently: ${vocab}.`;
    }

    const pedagogicalGoals = `
      - Your goal is to simulate a natural conversation.
      - Correct major grammatical errors immediately but gently.
      - Ignore minor slips to maintain flow, unless they affect meaning.
      - Ask open-ended questions to encourage the user to speak more.
    `;

    return `${baseIdentity}\n\n${levelContext}\n${memoryContext}\n${pedagogicalGoals}`;
  },

  /**
   * Prompt to analyze a completed conversation and extract learning data.
   */
  getAnalysisPrompt(transcript: string): string {
    return `
      Analyze the following English conversation transcript between a Tutor (model) and a Student (user).
      Identify:
      1. Up to 3 distinct grammatical or phrasing mistakes the user made. Provide the original phrasing, the correction, and a brief explanation.
      2. Up to 3 useful vocabulary words or idioms that were either introduced by the tutor or successfully used by the student.

      Return ONLY a valid JSON object with this structure:
      {
        "mistakes": [{"original": "string", "correction": "string", "explanation": "string"}],
        "vocabulary": [{"word": "string", "definition": "string", "example": "string"}]
      }

      Transcript:
      ${transcript}
    `;
  },

  /**
   * Prompt to generate a quiz based on user history.
   */
  getQuizPrompt(profile: UserProfile): string {
    const mistakes = profile.memory.recentMistakes.slice(0, 5);
    const vocab = profile.memory.vocabulary.slice(0, 5);
    
    const context = JSON.stringify({ mistakes, vocab });

    return `
      Generate a multiple-choice English quiz (3 questions) based on the following student data (recent mistakes and vocabulary).
      
      Student Data: ${context}
      
      If data is empty, generate general questions for ${profile.level} level.

      Return ONLY a valid JSON array of objects:
      [
        {
          "question": "string",
          "options": ["string", "string", "string", "string"],
          "correctIndex": number (0-3),
          "explanation": "string"
        }
      ]
    `;
  },

  /**
   * Prompt to generate a reading passage.
   */
  getReadingPrompt(level: string, topic: string): string {
    return `Write a short, engaging paragraph (approx 80 words) about "${topic}" suitable for an English learner at the ${level} level. Return only the text.`;
  }
};
