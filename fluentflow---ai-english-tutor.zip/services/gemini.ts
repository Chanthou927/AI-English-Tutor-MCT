import { GoogleGenAI } from "@google/genai";

// NOTE: Client-side Live API (WebSocket) usage requires a key or a proxy.
// Since we have removed the key from client-side build for security,
// Live API features will require a proxy implementation or re-introduction of a public-scoped key.
// For now, we initialize with a placeholder to prevent build errors.
export const ai = new GoogleGenAI({ apiKey: '' });

export const MODEL_IDS = {
  TEXT: 'gemini-2.5-flash',
  LIVE: 'gemini-2.5-flash-native-audio-preview-09-2025'
};

// --- Rate Limiter (Token Bucket Implementation) ---
class RateLimiter {
  private tokens: number;
  private maxTokens: number;
  private refillRate: number; // tokens per ms
  private lastRefill: number;

  constructor(maxRequests: number, timeWindowMs: number) {
    this.maxTokens = maxRequests;
    this.tokens = maxRequests;
    this.refillRate = maxRequests / timeWindowMs;
    this.lastRefill = Date.now();
  }

  check(): boolean {
    const now = Date.now();
    const timePassed = now - this.lastRefill;
    this.tokens = Math.min(this.maxTokens, this.tokens + timePassed * this.refillRate);
    this.lastRefill = now;

    if (this.tokens >= 1) {
      this.tokens -= 1;
      return true;
    }
    return false;
  }

  getRemainingTokens(): number {
    return Math.floor(this.tokens);
  }
}

// Allow 20 requests per minute
export const globalRateLimiter = new RateLimiter(20, 60000);

export class GeminiError extends Error {
  constructor(public message: string, public originalError: any, public isRetryable: boolean) {
    super(message);
  }
}

/**
 * Securely calls the backend API for text generation.
 * Replaces direct client-side chat for text interactions.
 */
export async function callGemini(messages: any[], systemInstruction?: string) {
  const res = await fetch('/api/gemini', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages, systemInstruction }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Gemini backend request failed');
  }
  
  const data = await res.json();
  return data.text;
}

export async function withRetry<T>(
  operation: () => Promise<T>, 
  retries = 3, 
  initialDelay = 1000
): Promise<T> {
  try {
    return await operation();
  } catch (error: any) {
    const status = error.status || error.response?.status;
    const isRetryable = status === 429 || (status >= 500 && status < 600);
    
    if (retries > 0 && isRetryable) {
      await new Promise(resolve => setTimeout(resolve, initialDelay));
      return withRetry(operation, retries - 1, initialDelay * 2);
    }
    
    throw new GeminiError(
      isRetryable ? "Service is temporarily busy. Please try again." : "An error occurred.",
      error,
      isRetryable
    );
  }
}