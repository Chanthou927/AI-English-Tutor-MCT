
/**
 * Logger Service
 * Abstraction layer for error reporting (e.g., Sentry, LogRocket).
 */

type LogLevel = 'info' | 'warn' | 'error';

class LoggerService {
  private isDev = process.env.NODE_ENV === 'development';

  init() {
    if (!this.isDev) {
      // Initialize Sentry or other monitoring tools here
      // Sentry.init({ dsn: "..." });
      console.log('Logger initialized in production mode');
    }
  }

  log(message: string, data?: any) {
    this.capture('info', message, data);
  }

  warn(message: string, data?: any) {
    this.capture('warn', message, data);
  }

  error(message: string, error?: any) {
    this.capture('error', message, error);
  }

  private capture(level: LogLevel, message: string, data?: any) {
    if (this.isDev) {
      const style = {
        info: 'color: #3b82f6',
        warn: 'color: #f59e0b',
        error: 'color: #ef4444; font-weight: bold',
      };
      console.group(`%c[${level.toUpperCase()}] ${message}`, style[level]);
      if (data) console.log(data);
      console.groupEnd();
    } else {
      // Send to Sentry/Service
      // if (level === 'error') Sentry.captureException(data);
      // else Sentry.captureMessage(message, level);
    }
  }
}

export const logger = new LoggerService();
