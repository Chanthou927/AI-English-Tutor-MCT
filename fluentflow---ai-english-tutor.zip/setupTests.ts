import '@testing-library/jest-dom';

declare const jest: any;

// Mock for AudioContext as it is not available in JSDOM
class MockAudioContext {
  state = 'suspended';
  createGain() { return { connect: jest.fn() }; }
  createScriptProcessor() { 
    return { 
      connect: jest.fn(), 
      onaudioprocess: null 
    }; 
  }
  createMediaStreamSource() { return { connect: jest.fn() }; }
  close() { return Promise.resolve(); }
}

(window as any).AudioContext = MockAudioContext;
(window as any).webkitAudioContext = MockAudioContext;

// Mock for getUserMedia
Object.defineProperty(window.navigator, 'mediaDevices', {
  value: {
    getUserMedia: jest.fn().mockResolvedValue({
      getTracks: () => [{ stop: jest.fn() }]
    })
  }
});